import './App.css';
import Tempapp from './component/Tempapp';

function App() {
  return (
    <div className="container">
      <Tempapp/>
     
    </div>
  );
}

export default App;
